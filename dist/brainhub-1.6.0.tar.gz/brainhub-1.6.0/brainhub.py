#!/usr/bin/env python3
"""BrainHub runtime-node knowledge workspace commands."""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import shutil
import sys
from datetime import UTC, datetime
from pathlib import Path

import brainhub_engine
from mcp_package.brainhub_core import artifact_store, render, wiki_publish
from mcp_package.brainhub_core.render.markdown_doc import render_markdown_file
from mcp_package.brainhub_core.artifacts import (
    ARTIFACT_DIRECTORIES,
    artifact_catalog as _core_artifact_catalog,
    backfill_artifact_sids as _core_backfill_artifact_sids,
    existing_artifact_sids as _core_existing_artifact_sids,
)
from mcp_package.brainhub_core.sid import (
    SID_TYPE_ARTIFACT,
    generate_sid as _core_generate_sid,
)


BRAINHUB_HOME_ENV = "BRAINHUB_HOME"
DEFAULT_HOME = Path("~/.brainhub")
RUNTIME_DIRECTORIES = (
    "knowledge/runbooks",
    "knowledge/syntheses",
    "artifacts/reports",
    "artifacts/html",
    "artifacts/charts",
    "artifacts/exports",
)
WORKSPACE_CONTRACT = """# BrainHub Workspace

BrainHub is a Runtime Node-local knowledge workspace for workflow agents.

## Write destinations

- `raw/`: immutable source material and captured inputs.
- `wiki/`: source-backed concepts, entities, comparisons, and reviewed memory.
- `knowledge/runbooks/`: reusable operational procedures.
- `knowledge/syntheses/`: source-backed conclusions that combine multiple artifacts or sources.
- `artifacts/reports/`: Markdown reports created by workflow agents.
- `artifacts/html/`: self-contained interactive HTML artifacts.
- `artifacts/charts/`: Mermaid, SVG, PNG, or chart-data outputs.
- `artifacts/exports/`: final files intended for external delivery.

Artifacts must record their source task, generating agent, creation time, and related wiki or knowledge pages in their frontmatter or a sidecar metadata file.

## Scope

This workspace is local to one Runtime Node Unix account. It is not a cross-VPS
sync service and must not be exposed as an unauthenticated network service.
"""


def default_workspace() -> Path:
    """Return the local workspace selected for this Runtime Node."""
    return Path(os.environ.get(BRAINHUB_HOME_ENV, str(DEFAULT_HOME))).expanduser()


def ensure_workspace(workspace: Path, *, command: str) -> None:
    """Exit loudly when the selected workspace is missing or uninitialized.

    Every verb except `init` needs a real workspace; silently returning empty
    results (search) or a bare traceback (read) hides a mis-pointed workspace.
    """
    resolved = Path(workspace).expanduser()
    if (resolved / "wiki" / "index.md").is_file():
        return
    if not resolved.exists():
        problem = f"workspace does not exist: {resolved}"
    else:
        problem = f"not an initialized BrainHub workspace (no wiki/index.md): {resolved}"
    print(f"brainhub {command}: {problem}", file=sys.stderr)
    print(
        "Pass the workspace path explicitly (brainhub <verb> ... <workspace>) "
        f"or set ${BRAINHUB_HOME_ENV}; create one first with: brainhub init <workspace>",
        file=sys.stderr,
    )
    raise SystemExit(2)


def initialize_workspace(workspace: Path) -> int:
    """Create the Link-compatible core plus BrainHub runtime directories."""
    workspace = workspace.expanduser().resolve()
    code = brainhub_engine.init_wiki(workspace)
    if code:
        return code
    for relative_path in RUNTIME_DIRECTORIES:
        (workspace / relative_path).mkdir(parents=True, exist_ok=True)
    contract = workspace / "BRAINHUB.md"
    if not contract.exists():
        contract.write_text(WORKSPACE_CONTRACT, encoding="utf-8")
    return 0


def add_artifact(
    source: Path,
    workspace: Path,
    *,
    kind: str,
    task: str,
    agent: str,
    related: list[str],
) -> int:
    """Copy a workflow output into BrainHub with machine-readable provenance."""
    source = source.expanduser().resolve()
    workspace = workspace.expanduser().resolve()
    destination_dir = workspace / ARTIFACT_DIRECTORIES[kind]
    if not source.is_file():
        raise ValueError(f"Artifact source is not a file: {source}")
    if not destination_dir.is_dir():
        raise ValueError(f"BrainHub workspace is not initialized: {workspace}")

    destination = destination_dir / source.name
    if destination.exists():
        raise ValueError(f"Artifact already exists: {destination}")
    shutil.copy2(source, destination)
    metadata = {
        "kind": kind,
        "sid": _core_generate_sid(SID_TYPE_ARTIFACT, _core_existing_artifact_sids(workspace)),
        "task": task,
        "agent": agent,
        "related": related,
        "source_name": source.name,
        "stored_path": destination.relative_to(workspace).as_posix(),
        "sha256": hashlib.sha256(destination.read_bytes()).hexdigest(),
        "created_at": datetime.now(UTC).isoformat(),
    }
    metadata_path = destination.with_name(destination.name + ".meta.json")
    metadata_path.write_text(json.dumps(metadata, indent=2) + "\n", encoding="utf-8")
    print(f"Stored {kind} artifact: {destination}")
    return 0


def artifact_catalog(workspace: Path, *, kind: str | None = None) -> dict[str, object]:
    """Return valid artifact records stored under this BrainHub workspace."""
    workspace = workspace.expanduser().resolve()
    payload = _core_artifact_catalog(workspace, kind=kind)
    return {"workspace": str(workspace), **payload}


def _load_spec(spec_source: Path) -> dict:
    """Load a render spec from a JSON file, or from stdin when source is '-'."""
    if str(spec_source) == "-":
        raw = sys.stdin.read()
    else:
        raw = Path(spec_source).expanduser().read_text(encoding="utf-8")
    spec = json.loads(raw)
    if not isinstance(spec, dict):
        raise ValueError("render spec must be a JSON object")
    return spec


def build_artifact(
    spec_source: Path,
    workspace: Path,
    *,
    renderer: str,
    task: str,
    agent: str,
    related: list[str],
    static: bool,
    title: str | None,
    name: str | None,
) -> int:
    """Render a spec into a self-contained HTML artifact and store it with provenance.

    Provenance is embedded (strippable) in the workspace copy AND written to the
    sidecar catalog record. `bh-export` strips the embedded block on the way out.
    """
    spec = _load_spec(spec_source)
    info = artifact_store.build_and_store_artifact(
        spec,
        workspace,
        renderer=renderer,
        task=task,
        agent=agent,
        related=related,
        static=static,
        title=title,
        name=name,
    )
    print(f"Built {info['kind']} artifact ({renderer}): {info['path']}")
    return 0


def export_artifact(
    artifact: Path,
    workspace: Path,
    *,
    target: Path,
    force: bool,
) -> int:
    """Write a stored artifact to a target path for a human, stripping provenance.

    The exported file must never carry workspace-internal provenance to a client,
    so the embedded provenance block is removed and the sidecar is NOT copied.
    """
    info = artifact_store.export_stored_artifact(
        artifact,
        workspace,
        target=target,
        force=force,
    )
    print(f"Exported artifact (provenance stripped): {info['target']}")
    return 0


def _read_body(body: str | None, body_file: Path | None) -> str:
    """Resolve document body markdown from --body, --body-file, or stdin."""
    if body_file is not None:
        return Path(body_file).expanduser().read_text(encoding="utf-8")
    if body is None:
        return sys.stdin.read()
    if body == "-":
        return sys.stdin.read()
    return body


def publish_document_command(
    workspace: Path,
    *,
    title: str,
    body: str | None,
    body_file: Path | None,
    links: list[str],
    artifact: str | None,
    agent: str,
    tags: list[str],
    as_json: bool,
) -> int:
    """Publish or update a wiki document page (bh-publish)."""
    result = wiki_publish.publish_document(
        workspace,
        title,
        _read_body(body, body_file),
        links=links,
        related_artifact=artifact,
        agent=agent,
        tags=tags,
    )
    if as_json:
        print(json.dumps(result, indent=2))
    else:
        action = "Updated" if result["updated"] else "Published"
        print(f"{action} document [{result['handle']}]: {result['path']}")
        if result.get("sid"):
            print(f"Sid: {result['sid']}")
        if result.get("tags"):
            print(f"Tags: {', '.join(result['tags'])}")
        if result.get("links"):
            print(f"Links: {', '.join(result['links'])}")
        for warning in result.get("warnings", []):
            print(f"Warning: {warning}")
    return 0


def read_document_command(workspace: Path, *, handle: str, as_json: bool, body_only: bool = False) -> int:
    """Read a published wiki document page back (bh-read)."""
    result = wiki_publish.read_document(workspace, handle, body_only=body_only)
    if as_json:
        print(json.dumps(result, indent=2, default=str))
    else:
        text = result["body"] if body_only else result["markdown"]
        print(text, end="" if text.endswith("\n") else "\n")
    return 0



def render_markdown_command(
    source: Path,
    *,
    out: Path | None,
    title: str,
    profile: str,
    css_files: list[Path],
    body_class: str,
    static: bool,
) -> int:
    if not source.is_file():
        print(f"markdown file not found: {source}")
        return 1
    html = render_markdown_file(
        source, title=title, profile=profile, css_files=css_files,
        body_class=body_class, static=static,
    )
    target = out or source.with_suffix(".html")
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(html, encoding="utf-8")
    print(f"Rendered: {target}")
    return 0

def search_documents_command(
    workspace: Path,
    *,
    query: str,
    limit: int,
    documents_only: bool,
    as_json: bool,
    tags: list[str] | None = None,
) -> int:
    """Search wiki pages, returning stable handles + snippets (bh-search)."""
    results = wiki_publish.search_documents(
        workspace,
        query,
        limit=limit,
        documents_only=documents_only,
        tags=tags,
    )
    if as_json:
        print(json.dumps(results, indent=2, default=str))
    else:
        print(f"Matches: {len(results)}")
        for record in results:
            print(f"- [{record['handle']}] {record['title']} ({record['category']})")
            if record["snippet"]:
                print(f"    {record['snippet']}")
    return 0


def sid_backfill_command(workspace: Path, *, as_json: bool) -> int:
    """Assign sids to existing documents + artifacts lacking one (one-time engine backfill)."""
    documents = wiki_publish.backfill_document_sids(workspace)
    artifacts = _core_backfill_artifact_sids(Path(workspace).expanduser())
    if as_json:
        print(json.dumps({"documents": documents, "artifacts": artifacts}, indent=2))
    else:
        print(f"Assigned document sids: {documents['count']}")
        for item in documents["assigned"]:
            print(f"- {item['sid']}: {item['page']}")
        print(f"Assigned artifact sids: {artifacts['count']}")
        for item in artifacts["assigned"]:
            print(f"- {item['sid']}: {item['artifact']}")
    return 0


def link_documents_command(
    workspace: Path,
    *,
    from_handle: str,
    to_handle: str,
    as_json: bool,
) -> int:
    """Create a wiki link from a document to another page (bh-link)."""
    result = wiki_publish.link_documents(workspace, from_handle, to_handle)
    if as_json:
        print(json.dumps(result, indent=2, default=str))
    else:
        if result["added"]:
            print(f"Linked [{result['from_handle']}] -> [[{result['to_handle']}]]")
        else:
            print(f"Already linked [{result['from_handle']}] -> [[{result['to_handle']}]]")
    return 0


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="brainhub", description="BrainHub Runtime Node-local knowledge workspace")
    subparsers = parser.add_subparsers(dest="command", required=True)
    init_command = subparsers.add_parser("init", help="create or repair a BrainHub workspace")
    init_command.add_argument("workspace", nargs="?", type=Path, default=default_workspace())
    init_command.add_argument("--home", dest="home_agent", help="also ensure '<agent> home' page exists (aworkr convention: knowledge map grows from the home page)")
    artifact_command = subparsers.add_parser("artifact", help="store a workflow artifact with provenance")
    artifact_subparsers = artifact_command.add_subparsers(dest="artifact_command", required=True)
    artifact_add = artifact_subparsers.add_parser("add", help="copy an artifact into the workspace")
    artifact_add.add_argument("source", type=Path)
    artifact_add.add_argument("workspace", nargs="?", type=Path, default=default_workspace())
    artifact_add.add_argument("--kind", choices=tuple(ARTIFACT_DIRECTORIES), required=True)
    artifact_add.add_argument("--task", required=True, help="workflow task that produced the artifact")
    artifact_add.add_argument("--agent", required=True, help="Runtime Node worker that generated the artifact")
    artifact_add.add_argument("--related", action="append", default=[], help="related BrainHub knowledge or wiki path; repeatable")
    artifact_list = artifact_subparsers.add_parser("list", help="list stored artifact records")
    artifact_list.add_argument("workspace", nargs="?", type=Path, default=default_workspace())
    artifact_list.add_argument("--kind", choices=tuple(ARTIFACT_DIRECTORIES))
    artifact_list.add_argument("--json", action="store_true", help="print machine-readable catalog data")

    build_command = subparsers.add_parser(
        "build",
        help="render a spec into a self-contained HTML artifact (bh-build)",
    )
    build_command.add_argument("spec", type=Path, help="path to a JSON render spec, or '-' for stdin")
    build_command.add_argument("workspace", nargs="?", type=Path, default=default_workspace())
    build_command.add_argument(
        "--renderer",
        required=True,
        help=f"renderer kind; available: {', '.join(render.registry.kinds()) or '(none registered)'}",
    )
    build_command.add_argument("--task", required=True, help="workflow task that produced the artifact")
    build_command.add_argument("--agent", required=True, help="Runtime Node worker that generated the artifact")
    build_command.add_argument("--related", action="append", default=[], help="related BrainHub knowledge or wiki path; repeatable")
    build_command.add_argument("--static", action="store_true", help="flatten animation/transition for headless PNG/PDF capture")
    build_command.add_argument("--title", help="artifact title (defaults to the renderer's suggestion)")
    build_command.add_argument("--name", help="output filename (defaults to a slug of the title; .html enforced)")

    render_command = subparsers.add_parser(
        "render",
        help="render a markdown file into ONE self-contained, brand-styled HTML file (bh-render)",
    )
    render_command.add_argument("source", type=Path, help="path to a markdown file")
    render_command.add_argument("workspace", nargs="?", type=Path, default=default_workspace())
    render_command.add_argument("--out", type=Path, help="output .html path (default: alongside the source)")
    render_command.add_argument("--title", default="", help="document title (default: the leading '# ' heading)")
    render_command.add_argument(
        "--profile",
        choices=("screen", "a4"),
        default="screen",
        help="'a4' adds print geometry + page-break discipline (attachments start a new page)",
    )
    render_command.add_argument(
        "--css",
        dest="css_files",
        action="append",
        default=[],
        type=Path,
        help="extra stylesheet to inline (document-specific chrome); repeatable",
    )
    render_command.add_argument(
        "--body-class",
        dest="body_class",
        default="",
        help="extra class on the body wrapper, so your --css has a selector to hook "
             "(the wrapper is always `.bh-doc`; this is added next to it)",
    )
    render_command.add_argument("--static", action="store_true", help="flatten animation for headless PNG/PDF capture")

    export_command = subparsers.add_parser(
        "export",
        help="write a stored artifact to a target path, stripping provenance (bh-export)",
    )
    export_command.add_argument("artifact", type=Path, help="stored artifact path (workspace-relative or absolute)")
    export_command.add_argument("workspace", nargs="?", type=Path, default=default_workspace())
    export_command.add_argument("--to", dest="target", required=True, type=Path, help="destination path for the human-facing file")
    export_command.add_argument("--force", action="store_true", help="overwrite the target if it already exists")

    publish_command = subparsers.add_parser(
        "publish",
        help="publish or update a wiki document page (bh-publish); same title updates in place",
    )
    publish_command.add_argument("title", help="document title (its slug is the stable handle)")
    publish_command.add_argument("workspace", nargs="?", type=Path, default=default_workspace())
    publish_body = publish_command.add_mutually_exclusive_group()
    publish_body.add_argument("--body", help="document body markdown ('-' or omit both to read stdin)")
    publish_body.add_argument("--body-file", dest="body_file", type=Path, help="read body markdown from a file")
    publish_command.add_argument("--link", dest="links", action="append", default=[], help="wiki page/handle to link to; repeatable")
    publish_command.add_argument("--artifact", help="related built artifact (stored path or name) to reference")
    publish_command.add_argument("--agent", default="bh-publish", help="worker publishing the document")
    publish_command.add_argument("--tag", dest="tags", action="append", default=[], help="document tag; repeatable")
    publish_command.add_argument("--json", action="store_true", help="print machine-readable result")

    read_command = subparsers.add_parser("read", help="read a published wiki document page (bh-read)")
    read_command.add_argument("handle", help="document handle, title, or wiki/documents/<handle>.md")
    read_command.add_argument("workspace", nargs="?", type=Path, default=default_workspace())
    read_command.add_argument("--json", action="store_true", help="print markdown + parsed metadata as JSON")
    read_command.add_argument("--body-only", dest="body_only", action="store_true", help="print only the document body (skip the frontmatter/markdown duplication; saves context on large pages)")

    search_command = subparsers.add_parser("search", help="search wiki pages, returning handle + snippet (bh-search)")
    search_command.add_argument("query", help="search query; tokens tag:<v>, from:<v>, domain:<v>, project:<v> act as tag filters (colon or dash form both accepted)")
    search_command.add_argument("workspace", nargs="?", type=Path, default=default_workspace())
    search_command.add_argument("--limit", type=int, default=20, help="maximum results (default 20)")
    search_command.add_argument("--documents-only", action="store_true", help="restrict to the document layer")
    search_command.add_argument("--tag", dest="tags", action="append", default=[], help="only pages carrying this tag; colon or dash form (from:catalog == from-catalog); repeatable, all must match")
    search_command.add_argument("--json", action="store_true", help="print machine-readable results")

    link_command = subparsers.add_parser("link", help="add a wiki link from a document to another page (bh-link)")
    link_command.add_argument("from_handle", metavar="from", help="source document handle/title/sid")
    link_command.add_argument("to_handle", metavar="to", help="existing target page handle/title/sid")
    link_command.add_argument("workspace", nargs="?", type=Path, default=default_workspace())
    link_command.add_argument("--json", action="store_true", help="print machine-readable result")

    sid_backfill_command_parser = subparsers.add_parser(
        "sid-backfill",
        help="assign sids to existing documents and artifacts that lack one (one-time engine backfill)",
    )
    sid_backfill_command_parser.add_argument("workspace", nargs="?", type=Path, default=default_workspace())
    sid_backfill_command_parser.add_argument("--json", action="store_true", help="print machine-readable result")

    home_command = subparsers.add_parser(
        "home",
        help="ensure an agent's home page exists (idempotent; NEVER overwrites an existing home)",
    )
    home_command.add_argument("agent", help="worker name; page title '<agent> home', stable handle '<agent>-home'")
    home_command.add_argument("workspace", nargs="?", type=Path, default=default_workspace())
    return parser


HOME_SKELETON = """# {agent} home

我的 brainhub 地圖（aworkr 慣例：wiki/memory/artifact 全從這頁長出；**新 publish 完記得 `bh link` 回這頁**）。

## 參考 / Runbook
(暫無)

## 進行中
(暫無)

## Artifact
(暫無)
"""


def ensure_home_page(workspace: Path, agent: str) -> int:
    """Idempotent: create '<agent> home' if missing; never touch an existing one (it is the agent's curated map)."""
    handle = f"{agent} home".strip().lower().replace(" ", "-")
    page = Path(workspace) / "wiki" / "documents" / f"{handle}.md"
    if page.exists():
        print(f"Home exists, unchanged: {handle}")
        return 0
    return publish_document_command(
        Path(workspace),
        title=f"{agent} home",
        body=HOME_SKELETON.format(agent=agent),
        body_file=None,
        links=[],
        artifact=None,
        agent=agent,
        tags=["home"],
        as_json=False,
    )


def _own_commands() -> set[str]:
    for action in build_parser()._actions:
        if isinstance(action, argparse._SubParsersAction):
            return set(action.choices)
    return set()


def _forward_to_engine(argv: list[str]) -> int:
    # Engine verbs default `target` to "." — the caller's cwd. Forwarding argv as-is
    # would therefore ignore BRAINHUB_HOME, and a tenant's `bh` (which pins its vault
    # purely through that env var) would silently read whatever brain happened to sit
    # in the cwd. Absolutize real paths against the caller's cwd first, then run the
    # engine from inside the workspace so its "." lands on the intended brain.
    cwd = Path.cwd()
    resolved = [argv[0]] + [
        str((cwd / arg).resolve()) if not arg.startswith("-") and (cwd / arg).exists() else arg
        for arg in argv[1:]
    ]
    workspace = default_workspace()
    if not workspace.is_dir():
        return brainhub_engine.main(resolved)
    os.chdir(workspace)
    try:
        return brainhub_engine.main(resolved)
    finally:
        os.chdir(cwd)


def main(argv: list[str] | None = None) -> int:
    argv = list(sys.argv[1:] if argv is None else argv)
    # One CLI, one brand. Verbs this wrapper does not own (health, doctor, validate,
    # query, backup, …) belong to the engine, so forward them instead of making the
    # fleet remember a second command name.
    if argv and not argv[0].startswith("-") and argv[0] not in _own_commands():
        return _forward_to_engine(argv)
    args = build_parser().parse_args(argv)
    # `render` is a pure file transform (markdown in, one HTML file out) — it never
    # touches the brain, so demanding a workspace would make it unusable in exactly
    # the place it is most needed: a tenant's drafts/, or anywhere with no brain at
    # all. `init` obviously predates its own workspace.
    if args.command not in {"init", "render"}:
        ensure_workspace(args.workspace, command=args.command)
    try:
        return _dispatch(args)
    except ValueError as exc:
        print(f"brainhub {args.command}: {exc}", file=sys.stderr)
        return 1


def _dispatch(args: argparse.Namespace) -> int:
    if args.command == "init":
        rc = initialize_workspace(args.workspace)
        if rc == 0 and getattr(args, "home_agent", None):
            rc = ensure_home_page(args.workspace, args.home_agent)
        return rc
    if args.command == "home":
        return ensure_home_page(args.workspace, args.agent)
    if args.command == "artifact" and args.artifact_command == "add":
        return add_artifact(
            args.source,
            args.workspace,
            kind=args.kind,
            task=args.task,
            agent=args.agent,
            related=args.related,
        )
    if args.command == "artifact" and args.artifact_command == "list":
        catalog = artifact_catalog(args.workspace, kind=args.kind)
        if args.json:
            print(json.dumps(catalog, indent=2))
        else:
            print(f"Artifacts: {catalog['count']}")
            artifacts = catalog["artifacts"]
            assert isinstance(artifacts, list)
            for record in artifacts:
                assert isinstance(record, dict)
                print(f"- {record['kind']}: {record['stored_path']} ({record.get('task', 'unknown task')})")
        return 0
    if args.command == "build":
        return build_artifact(
            args.spec,
            args.workspace,
            renderer=args.renderer,
            task=args.task,
            agent=args.agent,
            related=args.related,
            static=args.static,
            title=args.title,
            name=args.name,
        )
    if args.command == "render":
        return render_markdown_command(
            args.source,
            out=args.out,
            title=args.title,
            profile=args.profile,
            css_files=args.css_files,
            body_class=args.body_class,
            static=args.static,
        )
    if args.command == "export":
        return export_artifact(
            args.artifact,
            args.workspace,
            target=args.target,
            force=args.force,
        )
    if args.command == "publish":
        return publish_document_command(
            args.workspace,
            title=args.title,
            body=args.body,
            body_file=args.body_file,
            links=args.links,
            artifact=args.artifact,
            agent=args.agent,
            tags=args.tags,
            as_json=args.json,
        )
    if args.command == "read":
        return read_document_command(args.workspace, handle=args.handle, as_json=args.json, body_only=args.body_only)
    if args.command == "search":
        return search_documents_command(
            args.workspace,
            query=args.query,
            limit=args.limit,
            documents_only=args.documents_only,
            as_json=args.json,
            tags=args.tags,
        )
    if args.command == "link":
        return link_documents_command(
            args.workspace,
            from_handle=args.from_handle,
            to_handle=args.to_handle,
            as_json=args.json,
        )
    if args.command == "sid-backfill":
        return sid_backfill_command(args.workspace, as_json=args.json)
    raise AssertionError(f"Unhandled command: {args.command}")


if __name__ == "__main__":
    raise SystemExit(main())
