# BrainHub — architecture and contract

BrainHub is a node-local knowledge management workspace for workflow agents.
(Install and quickstart live in `README.md`; this file is the design contract.)

It intentionally has no central server, remote MCP endpoint, or cross-node
sync. One Unix account on one node owns one workspace. Every local agent
configured for that account can retrieve bounded, source-backed context
through stdio MCP or the CLI.

## Workspace layout

```text
<workspace>/                   # any directory; created by `bh init`
├── BRAINHUB.md                # workspace contract (written at init)
├── BRAINHUB-SCHEMA.md         # agent-facing schema instructions
├── raw/                       # immutable source documents (humans drop these)
├── wiki/                      # published documents + reviewed memory
│   ├── documents/             # `bh publish` output (reports, plans, diagnoses)
│   ├── index.md               # master catalog
│   └── log.md                 # chronological operation record
├── knowledge/                 # runbooks and source-backed syntheses
└── artifacts/
    ├── html/                  # self-contained interactive deliverables (`bh build`)
    ├── charts/                # rendered charts / mermaid
    ├── reports/               # markdown reports with provenance
    └── exports/               # final external outputs (PDF via chrome wrapper)
```

## Provenance

`bh artifact add` never modifies the source artifact. It copies it into the
workspace and writes a `<filename>.meta.json` sidecar containing its kind,
source task, generating agent, related knowledge links, timestamp, stored
path, and SHA-256 checksum. `bh export` strips embedded provenance on the way
out, so client-facing files never carry workspace internals.

## Agent access

Agents use the local stdio MCP connection (`pip install ./mcp_package`,
configure `--wiki <workspace>/wiki`) or the CLI — never a remote endpoint.

- Recommended slim surface: `admin(action="artifacts", arguments='{"kind":"report"}')`.
- Full compatibility surface: `list_artifacts(kind="report")`.

Both are read-only catalog queries returning provenance metadata; artifact
files are not transferred, rendered, or executed through MCP.

Humans browse the same workspace through the viewer (`serve.py`) on a trusted
private LAN. The viewer is read-mostly, but its write endpoints have **no
authentication** — deployment assumes every caller on the network is trusted;
never expose the port publicly.

## Compatibility boundary

### Engine module

Storage, search, validation, and the memory layer live in
`brainhub_engine.py`; `brainhub.py` is the product CLI in front of it and
forwards engine verbs it does not own. The product contract is `brainhub.py`
(alias `bh`) and the `BRAINHUB_HOME` workspace convention — documentation must
not present any other location as the default.

### License

BrainHub is a hard fork of an MIT-licensed project. MIT requires the original
copyright notice to survive in copies, so `LICENSE` is retained verbatim and is
the single place upstream attribution lives. Nothing else in the tree carries
upstream branding — `tests/test_brainhub_branding.py` enforces that.

## Non-goals

- No shared central BrainHub service.
- No cross-node live replication.
- No unauthenticated HTTP exposure.
- No automatic promotion of workflow output to durable memory.

Knowledge and memory promotion remain explicit: artifacts are preserved first,
then agents can compile source-backed wiki pages or submit durable-memory
proposals for review.
