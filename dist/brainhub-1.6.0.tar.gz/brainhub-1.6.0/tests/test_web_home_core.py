import sys
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "mcp_package"))

from brainhub_core.web_home import plural_type_label, render_home_page  # noqa: E402


def _layout(title: str, body: str) -> str:
    return f"<title>{title}</title>{body}"


def test_plural_type_label_handles_irregular_labels():
    assert plural_type_label("source") == "sources"
    assert plural_type_label("concept") == "concepts"
    assert plural_type_label("entity") == "entities"
    assert plural_type_label("memory") == "memories"


def test_render_home_page_shows_stats_sections_and_prompts():
    pages = [
        {"name": "index", "title": "Index", "type": "", "category": "root"},
        {
            "name": "agent-memory",
            "title": "Agent Memory",
            "type": "concept",
            "category": "concepts",
            "date_updated": "2026-05-01",
        },
        {
            "name": "local-memory",
            "title": "Local Memory",
            "type": "memory",
            "category": "memories",
            "date_updated": "2026-05-02",
        },
    ]
    prompts = {"prompts": [{"prompt": "is Link ready?"}, {"prompt": "ingest raw/<file> into Link"}]}

    html = render_home_page(
        pages,
        starter_prompts=prompts,
        page_href=lambda name: f"/page/{name}",
        layout=_layout,
    )

    assert "<title>BrainHub</title>" in html
    assert "agent 記憶是其中一層" in html
    assert '<span class="label">記憶</span>' in html
    assert '<h2>concepts</h2>' in html
    assert "/page/agent-memory" in html
    assert "試試這些提示詞" in html
    assert "is Link ready?" in html
    assert 'data-copy-text="is Link ready?"' in html
    assert "ingest raw/&lt;file&gt; into Link" in html
    assert 'data-copy-text="ingest raw/&lt;file&gt; into Link"' in html
    assert "下一步" in html
    assert "最近更新" in html
    assert html.index("Local Memory") < html.index("Agent Memory")
    assert "更新於 2026-05-02" in html
    assert 'href="/onboard"' in html
    assert 'href="/health"' in html
    assert 'href="/ingest"' in html
    assert 'href="/memory"' in html
    assert 'href="/graph"' in html
    assert "Index" not in html


def test_render_home_page_escapes_page_fields():
    pages = [
        {"name": "bad", "title": "<script>", "type": "<concept>", "category": "<concepts>"},
    ]

    html = render_home_page(pages, starter_prompts={"prompts": []}, page_href=lambda name: f"/page/{name}", layout=_layout)

    assert "&lt;concepts&gt;" in html
    assert "&lt;script&gt;" in html
    assert "&lt;concept&gt;" in html
    assert "<script>" not in html


def test_render_home_page_handles_empty_wiki():
    html = render_home_page([], starter_prompts={"prompts": []}, page_href=lambda name: f"/page/{name}", layout=_layout)

    assert "wiki 目前是空的" in html
    assert 'href="/ingest"' in html
    assert 'data-copy-text="把新的 raw 檔案匯入 BrainHub"' in html
    assert "複製匯入提示詞" in html


def test_render_home_page_hides_memory_card_when_memory_disabled():
    html = render_home_page(
        [],
        starter_prompts={"prompts": []},
        page_href=lambda name: f"/page/{name}",
        layout=_layout,
        memory_enabled=False,
    )

    assert 'href="/memory"' not in html
    # non-memory next-step cards survive
    assert 'href="/health"' in html
    assert 'href="/graph"' in html
