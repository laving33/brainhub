import sys
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "mcp_package"))

from brainhub_core.web_layout import render_footer_html, render_header_html, render_layout, render_stat_grid  # noqa: E402


class WebLayoutCoreTests(unittest.TestCase):
    def test_header_has_primary_navigation_and_search(self):
        html = render_header_html()

        self.assertIn('<a href="/ingest">匯入</a>', html)
        self.assertIn('<a href="/health">健康度</a>', html)
        self.assertIn('<a href="/brief">記憶簡報</a>', html)
        self.assertIn('<a href="/propose">草擬記憶</a>', html)
        self.assertIn('<a href="/graph">知識圖譜</a>', html)
        self.assertIn('<a href="/artifacts">產出</a>', html)
        self.assertIn('<a href="/documents">文件</a>', html)
        self.assertIn('class="nav-more"', html)
        self.assertIn('<summary>更多</summary>', html)
        self.assertIn('id="search-input"', html)
        self.assertIn('aria-label="搜尋 BrainHub"', html)
        self.assertIn("data-theme-toggle", html)
        self.assertIn("<svg", html)

    def test_footer_carries_brand_without_outbound_link(self):
        html = render_footer_html()

        self.assertIn("BrainHub", html)
        self.assertNotIn("github", html.lower())

    def test_layout_escapes_title_and_page_class(self):
        html = render_layout('<Title>', "<main>Body</main>", page_class='graph" onclick="bad')

        self.assertIn("<title>&lt;Title&gt; — BrainHub</title>", html)
        self.assertIn('class="graph&quot; onclick=&quot;bad"', html)
        self.assertIn("<main>Body</main>", html)
        self.assertIn("document.activeElement.id === 'search-input'", html)
        self.assertIn("window.location.href = '/search?q=' + encodeURIComponent(q);", html)
        self.assertIn("active.setAttribute('aria-current', 'page');", html)
        self.assertIn("current.indexOf('/page/') === 0", html)
        self.assertIn("localStorage.getItem('brainhub-theme')", html)
        self.assertIn("navigator.clipboard.writeText", html)
        self.assertIn("/api/raw-source", html)
        self.assertIn('lang="zh-Hant-TW"', html)
        self.assertIn("--brand-dawn-gold", html)

    def test_stat_grid_escapes_values_and_labels(self):
        html = render_stat_grid([("<2>", "raw <files>")])

        self.assertIn("home-stats", html)
        self.assertIn("&lt;2&gt;", html)
        self.assertIn("raw &lt;files&gt;", html)
        self.assertNotIn("<2>", html)


if __name__ == "__main__":
    unittest.main()
