"""Contract tests for the `read` verb (bh-read): brainhub.main(["read", ...]) and
wiki_publish.read_document.

Only this file is edited for this verb; the engine (mcp_package/brainhub_core/wiki_publish.py)
and CLI wiring (brainhub.py) are shared code owned by the architect / other writers.
"""
from __future__ import annotations

import io
import json
import tempfile
import unittest
from contextlib import redirect_stderr, redirect_stdout
from pathlib import Path

import brainhub
from mcp_package.brainhub_core import wiki_publish


class BhReadTests(unittest.TestCase):
    def _init_workspace(self, root: Path) -> Path:
        workspace = root / "brainhub"
        self.assertEqual(brainhub.main(["init", str(workspace)]), 0)
        return workspace

    def _publish(self, workspace: Path, title: str, body: str, *, extra: list[str] | None = None) -> None:
        code = brainhub.main(["publish", title, str(workspace), "--body", body, *(extra or [])])
        self.assertEqual(code, 0)

    # ------------------------------------------------------------------
    # (1) read_document returns the full contract dict, markdown/body correct
    # ------------------------------------------------------------------
    def test_read_document_returns_full_contract(self):
        with tempfile.TemporaryDirectory() as temp_dir:
            workspace = self._init_workspace(Path(temp_dir))
            self._publish(workspace, "Release Plan", "Ship it on Friday.", extra=["--agent", "tester"])

            result = wiki_publish.read_document(workspace, "release-plan")

            self.assertEqual(
                set(result.keys()),
                {"handle", "sid", "title", "path", "markdown", "body", "metadata", "related_artifact", "links"},
            )

            on_disk = (workspace / "wiki" / "documents" / "release-plan.md").read_text(encoding="utf-8")
            self.assertEqual(result["markdown"], on_disk)
            self.assertEqual(result["handle"], "release-plan")
            self.assertEqual(result["title"], "Release Plan")
            self.assertEqual(result["path"], "wiki/documents/release-plan.md")

            # body has frontmatter stripped: no leading '---' block, no frontmatter keys.
            self.assertFalse(result["body"].startswith("---"))
            self.assertNotIn("type: document", result["body"])
            self.assertIn("Ship it on Friday.", result["body"])
            self.assertIn("# Release Plan", result["markdown"])

            self.assertIsInstance(result["metadata"], dict)
            self.assertEqual(result["metadata"].get("title"), "Release Plan")
            self.assertEqual(result["metadata"].get("handle"), "release-plan")
            self.assertEqual(result["links"], [])
            self.assertIsNone(result["related_artifact"])

    # ------------------------------------------------------------------
    # (2) forgiving handle resolution: slug / title / <slug>.md / documents/<slug>
    # ------------------------------------------------------------------
    def test_handle_resolution_is_forgiving(self):
        with tempfile.TemporaryDirectory() as temp_dir:
            workspace = self._init_workspace(Path(temp_dir))
            self._publish(workspace, "Release Plan", "Ship it on Friday.")

            baseline = wiki_publish.read_document(workspace, "release-plan")
            for handle in ("release-plan", "Release Plan", "release-plan.md", "documents/release-plan"):
                result = wiki_publish.read_document(workspace, handle)
                self.assertEqual(
                    result["handle"], "release-plan", f"handle resolution failed for {handle!r}"
                )
                self.assertEqual(result["markdown"], baseline["markdown"])
                # every variant normalizes through the same helper the module exposes
                self.assertEqual(wiki_publish.normalize_handle(handle), "release-plan")

    # ------------------------------------------------------------------
    # (3) CLI prints markdown by default, and a JSON object with --json
    # ------------------------------------------------------------------
    def test_cli_read_prints_markdown_then_json(self):
        with tempfile.TemporaryDirectory() as temp_dir:
            workspace = self._init_workspace(Path(temp_dir))
            self._publish(workspace, "Release Plan", "Ship it on Friday.")

            out = io.StringIO()
            with redirect_stdout(out):
                code = brainhub.main(["read", "release-plan", str(workspace)])
            self.assertEqual(code, 0)
            self.assertIn("# Release Plan", out.getvalue())

            out_json = io.StringIO()
            with redirect_stdout(out_json):
                code = brainhub.main(["read", "release-plan", str(workspace), "--json"])
            self.assertEqual(code, 0)
            payload = json.loads(out_json.getvalue())
            self.assertEqual(payload["title"], "Release Plan")
            self.assertEqual(payload["handle"], "release-plan")

    # ------------------------------------------------------------------
    # (4) missing handle raises ValueError containing 'document not found'
    # ------------------------------------------------------------------
    def test_missing_handle_raises_value_error(self):
        with tempfile.TemporaryDirectory() as temp_dir:
            workspace = self._init_workspace(Path(temp_dir))

            with self.assertRaises(ValueError) as ctx:
                wiki_publish.read_document(workspace, "does-not-exist")
            self.assertIn("document not found", str(ctx.exception))

            # CLI reports the same error loudly (nonzero exit + stderr message,
            # never a bare traceback).
            stderr = io.StringIO()
            with redirect_stderr(stderr):
                code = brainhub.main(["read", "does-not-exist", str(workspace)])
            self.assertEqual(code, 1)
            self.assertIn("document not found", stderr.getvalue())

    # ------------------------------------------------------------------
    # body_only: skip the markdown/metadata duplication on large pages
    # ------------------------------------------------------------------
    def test_body_only_omits_markdown_and_metadata(self):
        with tempfile.TemporaryDirectory() as temp_dir:
            workspace = self._init_workspace(Path(temp_dir))
            self._publish(workspace, "Big Page", "A very distinctive xylographic body.")

            result = wiki_publish.read_document(workspace, "big-page", body_only=True)

            self.assertTrue(result["body_only"])
            self.assertNotIn("markdown", result)
            self.assertNotIn("metadata", result)
            self.assertIn("xylographic", result["body"])
            self.assertEqual(result["handle"], "big-page")

            # default behavior unchanged: markdown + metadata still returned
            full = wiki_publish.read_document(workspace, "big-page")
            self.assertIn("markdown", full)
            self.assertIn("metadata", full)

            # CLI flag prints the body without frontmatter
            output = io.StringIO()
            with redirect_stdout(output):
                code = brainhub.main(["read", "big-page", str(workspace), "--body-only"])
            self.assertEqual(code, 0)
            text = output.getvalue()
            self.assertIn("xylographic", text)
            self.assertNotIn("type: document", text)

    # ------------------------------------------------------------------
    # (5) related_artifact + forward links round-trip through publish --link/--artifact
    # ------------------------------------------------------------------
    def test_related_artifact_and_links_round_trip(self):
        with tempfile.TemporaryDirectory() as temp_dir:
            root = Path(temp_dir)
            workspace = self._init_workspace(root)

            self._publish(workspace, "Root Doc", "The root page other docs link to.")

            source = root / "release-report.md"
            source.write_text("# Release report\n", encoding="utf-8")
            code = brainhub.main(
                [
                    "artifact",
                    "add",
                    str(source),
                    str(workspace),
                    "--kind",
                    "report",
                    "--task",
                    "release-readiness",
                    "--agent",
                    "tester",
                ]
            )
            self.assertEqual(code, 0)

            self._publish(
                workspace,
                "Release Plan",
                "Ship it on Friday.",
                extra=[
                    "--link",
                    "root-doc",
                    "--artifact",
                    "artifacts/reports/release-report.md",
                ],
            )

            result = wiki_publish.read_document(workspace, "release-plan")
            self.assertIn("root-doc", result["links"])
            self.assertEqual(result["related_artifact"], "artifacts/reports/release-report.md")
            self.assertEqual(result["metadata"].get("related_artifact"), "artifacts/reports/release-report.md")


if __name__ == "__main__":
    unittest.main()
