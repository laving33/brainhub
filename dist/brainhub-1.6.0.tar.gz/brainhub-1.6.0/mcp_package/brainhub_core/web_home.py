"""HTML helpers for BrainHub's local home page."""
from __future__ import annotations

import html
from collections.abc import Callable, Mapping, Sequence

from .web_ingest import copy_button


PageHref = Callable[[str], str]
PageLayout = Callable[[str, str], str]


def plural_type_label(page_type: str) -> str:
    irregular = {"entity": "entities", "memory": "memories"}
    if page_type in irregular:
        return irregular[page_type]
    return page_type if page_type.endswith("s") else page_type + "s"


def render_home_page(
    pages: Sequence[dict[str, object]],
    *,
    starter_prompts: Mapping[str, object],
    page_href: PageHref,
    layout: PageLayout,
    memory_enabled: bool = True,
) -> str:
    body = (
        "<h1>BrainHub</h1>"
        "<p>內部 LLM wiki + 富 artifact，agent 記憶是其中一層。知識在這裡持續累積。</p>"
        f"{_render_product_lanes()}"
        f"{_render_prompt_strip(starter_prompts)}"
        f"{_render_next_steps(memory_enabled=memory_enabled)}"
        f"{_render_recent_pages(pages, page_href=page_href)}"
        f"{_render_stats(pages)}"
        f"{_render_page_sections(pages, page_href=page_href)}"
    )
    return layout("BrainHub", body)


def _render_stats(pages: Sequence[dict[str, object]]) -> str:
    counts: dict[str, int] = {}
    for page in pages:
        page_type = str(page.get("type") or "other")
        counts[page_type] = counts.get(page_type, 0) + 1

    stats_items = f'<div class="stat"><span class="num">{len(pages)}</span><span class="label">頁面</span></div>'
    type_labels = {
        "memory": "記憶",
        "source": "來源",
        "concept": "概念",
        "entity": "實體",
        "comparison": "比較",
        "exploration": "探索",
    }
    for page_type in ["memory", "source", "concept", "entity", "comparison", "exploration"]:
        count = counts.get(page_type, 0)
        if count > 0:
            stats_items += (
                f'<div class="stat"><span class="num">{count}</span>'
                f'<span class="label">{type_labels.get(page_type, plural_type_label(page_type))}</span></div>'
            )
    return f'<div class="home-stats">{stats_items}</div>'


def _render_page_sections(pages: Sequence[dict[str, object]], *, page_href: PageHref) -> str:
    categories: dict[str, list[dict[str, object]]] = {}
    for page in pages:
        category = str(page.get("category") or "")
        if category == "root":
            continue
        categories.setdefault(category, []).append(page)

    if not categories:
        return (
            '<div class="memory-next"><strong>wiki 目前是空的</strong>'
            "<ul>"
            '<li><a href="/ingest">新增第一份 raw 來源</a>。</li>'
            f"<li>{copy_button('把新的 raw 檔案匯入 BrainHub', '複製匯入提示詞')}</li>"
            "</ul></div>"
        )

    sections = ""
    for category in sorted(categories):
        items = "".join(
            f'<li><a href="{html.escape(page_href(str(page["name"])), quote=True)}">'
            f'{html.escape(str(page["title"]))}</a>'
            f'<span class="type">{html.escape(str(page.get("type") or ""))}</span></li>'
            for page in sorted(categories[category], key=lambda item: str(item.get("title") or ""))
        )
        sections += f'<h2>{html.escape(category)}</h2><ul class="page-list">{items}</ul>'
    return sections


def _render_recent_pages(pages: Sequence[dict[str, object]], *, page_href: PageHref, limit: int = 6) -> str:
    recent = [
        page for page in pages
        if str(page.get("category") or "") != "root" and str(page.get("date_updated") or "").strip()
    ]
    if not recent:
        return ""
    items = "".join(
        f'<li><a href="{html.escape(page_href(str(page["name"])), quote=True)}">'
        f'{html.escape(str(page["title"]))}</a>'
        f'<span class="type">{html.escape(str(page.get("type") or ""))} · 更新於 {html.escape(str(page.get("date_updated") or ""))}</span></li>'
        for page in sorted(recent, key=_recent_page_key, reverse=True)[:limit]
    )
    return (
        '<section class="home-recent">'
        '<div class="section-heading"><h2>最近更新</h2><a href="/all">所有頁面</a></div>'
        f'<ul class="page-list">{items}</ul>'
        "</section>"
    )


def _recent_page_key(page: Mapping[str, object]) -> tuple[str, str]:
    return str(page.get("date_updated") or ""), str(page.get("title") or "")


def _render_product_lanes() -> str:
    return (
        '<div class="product-lanes" aria-label="BrainHub 如何保存脈絡">'
        '<section class="product-lane"><h2>1. 來源變成 wiki 知識</h2>'
        '<p>把檔案放進 <code>raw/</code>，然後說 <code>把 raw/file.md 匯入 BrainHub</code>。'
        'BrainHub 會建立有來源依據的頁面、概念、反向連結、索引項目與紀錄。</p></section>'
        '<section class="product-lane"><h2>2. Remember 儲存 agent 記憶</h2>'
        '<p>當某個偏好、決策或專案事實應該影響之後的 agent 時，說 <code>remember that ...</code>。'
        '單純匯入不會悄悄影響之後的記憶回想。</p></section>'
        '<section class="product-lane"><h2>3. Query 安全地同時使用兩者</h2>'
        '<p>問 <code>query BrainHub for ...</code>，或開啟記憶簡報。BrainHub 會結合已審核的記憶、wiki 頁面與知識圖譜脈絡。</p></section>'
        '</div>'
    )


def _render_prompt_strip(starter_prompts: Mapping[str, object]) -> str:
    prompt_codes = ""
    for item in starter_prompts.get("prompts", []):
        if isinstance(item, dict):
            prompt = str(item.get("prompt") or "")
            prompt_codes += (
                '<div class="prompt-chip">'
                f"<code>{html.escape(prompt)}</code>"
                f"{copy_button(prompt, '複製')}"
                "</div>"
            )
    return (
        '<section class="prompt-strip" aria-label="BrainHub 入門提示詞">'
        '<h2>試試這些提示詞</h2>'
        '<p>可以請 Codex、Claude、Cursor、Kiro 或任何裝有 BrainHub 的 agent 試試看。<a href="/prompts">開啟入門提示詞</a>。</p>'
        '<div class="prompt-grid">'
        f"{prompt_codes}</div></section>"
    )


def _render_next_steps(memory_enabled: bool = True) -> str:
    actions = [
        ("上手引導", "/onboard", "健康度、第一則記憶、agent 連接，以及每日提示詞循環。"),
        ("檢查健康度", "/health", "就緒狀態、驗證、中斷的寫入，以及安全修復。"),
        ("新增來源", "/ingest", "先把 raw 筆記存到本機，再請 agent 匯入。"),
        ("檢視記憶", "/memory", "檢查已記住的偏好、決策與專案脈絡。"),
        ("探索知識圖譜", "/graph", "開啟關係、聚焦鄰近範圍與頁面佐證。"),
    ]
    if not memory_enabled:
        actions = [action for action in actions if action[1] != "/memory"]
    items = "".join(
        '<a class="home-next-card" href="'
        f'{html.escape(href, quote=True)}"><strong>{html.escape(label)}</strong>'
        f'<span>{html.escape(detail)}</span></a>'
        for label, href, detail in actions
    )
    return (
        '<section class="home-next" aria-label="下一步">'
        "<h2>下一步</h2>"
        f'<div class="home-next-grid">{items}</div>'
        "</section>"
    )
