"""Embed the brand faces INTO the file, subset to the glyphs actually used.

Why this is not a styling concern (and so cannot be left to ``--css``):

A CSS ``font-family`` declaration is a *request*. On the machine that produced the
document the font is installed, so the request is granted and the page looks right
— forever, to its author. On the recipient's machine it is not installed, the
request silently falls back to a system face, and the document they see is not the
document you approved. **You can never see this bug on your own screen.** It is
only visible to the person you sent it to, which is the client.

So: for anything print/client-facing, the bytes ride along. A full Noto Sans TC is
~9 MB, which is why we subset to exactly the characters the document contains —
a typical contract needs a few hundred glyphs and lands around 500 KB total.
"""
from __future__ import annotations

import base64
import io
import os
import re
from pathlib import Path

# White-label: point BRAINHUB_BRAND_FONTS at a directory of .ttf/.woff2 files to
# embed your own faces. Absent fonts degrade gracefully (no embed, no error).
BRAND_FONTS = Path(
    os.environ.get("BRAINHUB_BRAND_FONTS", "/home/aworkr/aworkr/core/library/brand/assets/fonts")
)

_TAG = re.compile(r"<[^>]+>")


def _b64(data: bytes) -> str:
    return base64.b64encode(data).decode("ascii")


def _subset_cjk(font_path: Path, text: str) -> bytes | None:
    """Subset the variable CJK face to `text`, as woff2. None if fontTools absent."""
    try:
        from fontTools import subset
        from fontTools.ttLib import TTFont
    except ImportError:  # pragma: no cover - depends on the install
        return None

    options = subset.Options(flavor="woff2", layout_features=["*"], drop_tables=[])
    options.desubroutinize = True
    font = TTFont(str(font_path), lazy=True)
    subsetter = subset.Subsetter(options)
    subsetter.populate(text=text)
    subsetter.subset(font)
    buffer = io.BytesIO()
    font.flavor = "woff2"
    font.save(buffer)
    font.close()
    return buffer.getvalue()


def embedded_font_css(html_body: str, *, fonts_dir: Path = BRAND_FONTS) -> str:
    """Return a <style> block with the brand faces inlined as data: URIs.

    Returns "" when the brand fonts are not on this machine (standalone install) —
    the document still renders, it just cannot guarantee its own typography.
    """
    if not fonts_dir.is_dir():
        return ""

    inter_light = fonts_dir / "Inter-Light.woff2"
    inter_regular = fonts_dir / "Inter-Regular.woff2"
    noto = fonts_dir / "NotoSansTC-var.ttf"
    if not (inter_light.is_file() and inter_regular.is_file() and noto.is_file()):
        return ""

    faces = [
        f'@font-face {{ font-family:"Inter"; font-weight:300; font-display:swap;'
        f' src:url(data:font/woff2;base64,{_b64(inter_light.read_bytes())}) format("woff2"); }}',
        f'@font-face {{ font-family:"Inter"; font-weight:400 700; font-display:swap;'
        f' src:url(data:font/woff2;base64,{_b64(inter_regular.read_bytes())}) format("woff2"); }}',
    ]

    # Subset to the document's own characters (plus digits, which tables grow later).
    used = "".join(sorted(set(_TAG.sub("", html_body)) | set("0123456789")))
    cjk = _subset_cjk(noto, used)
    if cjk:
        faces.append(
            f'@font-face {{ font-family:"Noto Sans TC"; font-weight:100 900; font-display:swap;'
            f' src:url(data:font/woff2;base64,{_b64(cjk)}) format("woff2-variations"); }}'
        )

    return "<style>" + "\n".join(faces) + "\nbody { font-weight: 300; }</style>"
