"""Shared BrainHub runtime helpers."""
